package July10.TestPolymorphism;

import examples.Person;

/**
 *
 * @author shohrehhadian-suleman
 */
public class Patient extends Person{
    
    Physician doc;
    
    Patient (String givenName, String surname, Physician d){
    super(givenName, surname);
    this.doc = d;
    
        
   }
    
    
    
    
    
    
}
