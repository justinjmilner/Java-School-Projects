package July10.TestPolymorphism;

/**
 *
 * @author shohrehhadian-suleman
 */
public class Surgeon extends Physician {
    
   String  residency;

    public Surgeon(String f, String l, String o, String job, String s, String r) {
        super(f, l, o, job, s);
        this.residency = r;
    }
    
    
    
    
   @Override
    public String toString(){
      String temp="";
      temp += super.toString()
              + "\n[Surgeon]"
              +this.residency;
        
      return temp;  
    }
    
   
}
