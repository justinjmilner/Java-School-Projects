
package July10.TestPolymorphism;

/**
 *
 * @author shohreh
 */
public class GradStudent extends Student {
    

    // instance variables
    
    String thesisTopic;
    String supervisor;
    String level;
   
    // constructors
    
   public GradStudent(){
        
        
    }
   public GradStudent(String t){
       //super(); 
      thesisTopic = t;  
      
    }
    
   public GradStudent(String t, String s){
      thesisTopic = t;
      supervisor =s;
       
    }
    
    @Override
   public String toString(){
        
      String temp ="";
      temp= supervisor+"\n"+thesisTopic+"\n"+level 
              +super.toString();
      
      return temp;
    }
    
    
}// end of class GradStudent
