
package July10.TestPolymorphism;

import examples.Person;

/**
 *
 * @author shohrehhadian-suleman
 */
public class TestPoly {

   
    public static void main(String[] args) {
       
        
//       String [] picked = pickRandomNames();
//       String first = picked[0];
//       String last = picked[1];
//       
//        Person p = new Person(first,last );
//        
//        // how would you avoid repeating this
//        picked = pickRandomNames();
//        first = picked[0];
//        last = picked[1];
//        
//        Person n1 = new Nurse(first, last, Nurse.Rank.RN);
//        
//        picked = pickRandomNames();
//        first = picked[0];
//        last = picked[1];
//        
//        Person e = new Employee(first,last,"RJH","Receptionist");
//        
//         picked = pickRandomNames();
//        first = picked[0];
//        last = picked[1];
//        
//        Person doc1 = new Physician(first,last,"RJH","Emergency","trauma");
//        
//        picked = pickRandomNames();
//        first = picked[0];
//        last = picked[1];
//        Person doc2 = new Surgeon(first,last,"RJH","Emergency","trauma","neurology");
//        
//        Person[] staff = {p,n1,e,doc1,doc2};
//        
//        String buffer ="";
//        for( int i = 0; i<staff.length; i++){
//           
//            buffer += staff[i].toString();
//            buffer += "\n====================\n";
//        }
//        System.out.println(buffer);
//        double money;
//        
//        money = doc1.grossPay();
//        System.out.println(money);
        
        // change to doc2 to show the static checking at compile time
//        money = e.grossPay();
//        System.out.println(money);
        
        /* change all to Person and then show the run time error vs. compile time error*/
        
       Physician[] myDocs =  pickRandomNames( );
        
    }
    
    
   static Physician[] pickRandomNames( ){
       Physician[]  list = new Physician[20];
       Physician p1 = null;
      String[] givenNames = {
	"Avery", "Riley", "Jordan", "Angel", "Peyton",
	"Quinn", "Hayden", "Taylor", "Alexis", "Rowan",
	"Charlie", "Emerson", "Finley", "River", "Emery",
	"Morgan", "Elliot", "London", "Eden", "Elliott",
	"Karter", "Dakota", "Reese", "Remington", "Payton",
	"Amari", "Phoenix", "Kendall", "Harley", "Rylan",
	"Marley", "Dallas", "Skyler", "Spencer", "Sage",
	"Kyrie", "Ellis", "Rory", "Remi", "Justice",
	"Ali", "Haven", "Tatum", "Arden", "Linden",
	"Devon", "Rebel", "Rio", "Ripley", "Frankie"
};
        
       String[] surnames = {
	"Smith", "Brown", "Tremblay", "Martin", "Roy",
	"Wilson", "Macdonald", "Gagnon", "Johnson", "Taylor",
	"Cote", "Campbell", "Anderson", "Leblanc", "Lee",
	"Jones", "White", "Williams", "Miller", "Thompson",
	"Gauthier", "Young", "Van", "Morin", "Bouchard",
	"Scott", "Stewart", "Belanger", "Reid", "Pelletier",
	"Moore", "Lavoie", "King", "Robinson", "Levesque",
	"Murphy", "Fortin", "Gagne", "Wong", "Clark",
	"Johnston", "Clarke", "Ross", "Walker", "Thomas",
	"Boucher", "Landry", "Kelly", "Bergeron", "Davis"
}; 
     String [] picked;
       
       for (int m=0; m<20; m++){
    
            int i = (int)(Math.random()* givenNames.length);
           int j = (int)(Math.random()* surnames.length);

           String first = givenNames[i];
           String  last = surnames[j];
           

           
            p1 = new Physician(first,last,"RJH","Chief","Cardiologist");
            list[m ] = p1;
       }
       
       
      return list; 
       
       
       
   } // end of pickRandome
    
    
    
    
}
