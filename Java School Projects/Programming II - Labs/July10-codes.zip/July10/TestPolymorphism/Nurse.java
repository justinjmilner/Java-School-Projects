 package July10.TestPolymorphism;

import examples.Person;

/**
 *
 * @author shohrehhadian-suleman
 */
public class Nurse extends Employee{
   
    public static enum Rank{
        LP,RN,ORN
        
    }
    private Rank rank;
    
    
    // how to use it in construcor
    
    public Nurse( String first, String last, Rank r){
        
       super(first,last);
       this.rank = r;
        
    }
    public Rank getRank() {
        return rank;
    }

    public void setRank(Rank rank) {
        this.rank = rank;
    }
    
    public String toString(){
        
        return super.toString()+"\n[Nurse] " +  this.rank;
    }
    
 //--------------------------
    
   public static void main(String[] args) {
       Nurse nurse1 = new Nurse ("Davis","Smith", Nurse.Rank.RN);
       Nurse nurse2 = new Nurse ("Evans", "Collen",Nurse.Rank.ORN);
      String result =  nurse1.toString();
      System.out.println(result);
      
      System.out.println(nurse2);
      
      
   } 
    
    
}
