package July10.TestPolymorphism;

import examples.Person;




/**
 *
 * @author shohreh
 */
public class Student extends Person{
    
    // instance variables
  private  String major;
    double gpa=0;
    String institution;
    static int noOfStudents;
    
   public Student(){
      // super(); 
    }
    
   public Student( String ins){
      institution = ins;  
    }
   public Student( String ins, String m){
      institution = ins; 
      major = m;
    }
    
    // setter  (write)
    public void setMajor(String m){
        this.major = m;
    }
    // getter  ( read)
    public String getMajor(){
        return this.major;
    }
    
    
    @Override
    public String toString(){
      String temp="";
      temp = "institution"+this.institution+" ,"+this.major+
              this.gpa +super.toString();
        
      return temp;  
    }
    
}
