package July10.TestPolymorphism;

/**
 *
 * @author shohrehhadian-suleman
 */
public class Physician extends Employee{
    
    String speciality;
    
  public  Physician( String f, String l ,String o, String job, String s ){
              super(f,l, o, job);
              this.speciality = s;
  }
    
    
    @Override
    public double grossPay(){
    return 250000;
    }
    // use this to show what happens when you have duplicate code
    // fixing one area does not fix the other code
//    public String toString(){
//      String temp="Employee ";
//      temp += "Organization"+this.organization+" ,"
//              +this.jobDescription +","
//              + this.fullTime + "\n"
//              +super.toString();
//        
//      return temp;  
//    }
    
    
    public String toString(){
      String temp="";
      temp += super.toString()
              + "[Physician]"
              +this.speciality;
        
      return temp;  
    }
    
}
