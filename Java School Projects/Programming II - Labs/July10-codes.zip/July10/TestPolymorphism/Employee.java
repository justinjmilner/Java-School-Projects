package July10.TestPolymorphism;

import examples.Person;



/**
 *
 * @author shohreh
 */
public class Employee extends Person {
    
    
    // instance variables
    String organization;
    String jobDescription;
    boolean fullTime;
    double pay;
    
    // constructors
    
   public Employee() {
     fullTime = false;   
        
    }
   public  Employee(String o, String job) {
      super();  
      organization = o;
      jobDescription = job; 
      fullTime = false;
    }
   public  Employee(String f, String l ,String o, String job) {
      super(f,l);  
      organization = o;
      jobDescription = job; 
      fullTime = false;
    }
    
 public  void promote(){
       fullTime = true;
   }
 public double grossPay(){
     return 80000;
 }
  
  public String toString(){
      String temp="";
      temp += super.toString()
              + "\n[Employee] "+ " "+this.organization+" ,"
              +this.jobDescription +", "
              + this.fullTime + "\n";
        
      return temp;  
    }
    
    
}
