package July10.TestInterface;

/**
 *
 * @author shohrehhadian-suleman
 */
public class Car implements CanTravel {

    private int distance = 0;
    private int year;
    private String model;

    public Car(int y, String model) {
        this.year = y;
        this.model = model;
    }

    public void drive() {
        System.out.println("Vrrooooom!");
    }

 
    @Override
    public int getTotalDistanceTravelled() {
        return this.distance;
    }

     @Override
    public void goTheDistance(int km) {
        this.drive();
        if (km > 1000) {
            System.out.println("Can't go that far on one tank of gas");
        } else {
            this.distance += km;
        }
        System.out.println("You have arrived");
    }
}
