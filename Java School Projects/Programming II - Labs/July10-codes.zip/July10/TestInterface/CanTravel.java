package July10.TestInterface;

/**
 *
 * @author shohrehhadian-suleman
 */
public interface CanTravel {
    
    /** Travel Somewhere that is the given distance in kilometer
     * 
     * @param km distance to travel
     */
   void goTheDistance(int km);
   
    /**
     * returns the total distance traveled by this object
     * @return - distance measurement in kilometer
     */
    int getTotalDistanceTravelled();
    
}
