package July10.TestInterface;

/**
 *
 * @author shohrehhadian-suleman
 */
public class TestVehicle {

  
    public static void main(String[] args) {
        
       Vehicle mazda = new Vehicle(2012, "Mazda 3");
       
       mazda.goTheDistance(300);
       mazda.goTheDistance(200);
       System.out.println(mazda.getTotalDistanceTravelled());
        
    }
    
}
