
package July10.TestAbstract;

/**
 *
 * @author shohrehhadian-suleman
 */
public abstract class Animal {
    int age;
    String gender = "N/A";
            
            
    abstract void eat();
   
      void sleep(){
       System.out.println("ZZZzzzzzzz");  
     }
}
