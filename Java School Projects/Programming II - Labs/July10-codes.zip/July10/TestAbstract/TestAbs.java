
package July10.TestAbstract;

/**
 *
 * @author shohrehhadian-suleman
 */
public class TestAbs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       // Animal a1 = new Animal();  // cannot do this since it is an abstract class - Work in progress
       Animal b1 = new Bear();
       Animal d1 = new Dog();
       b1.sleep();
       d1.eat();   // dynamic binding.  looks for a method in a class at run time
       b1.eat();
       
      //  Fish f1 = new Fish();
    }
    
}
