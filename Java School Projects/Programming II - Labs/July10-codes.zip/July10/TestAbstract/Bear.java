
package July10.TestAbstract;

/**
 *
 * @author shohrehhadian-suleman
 */
public  class Bear extends Animal{
    public Bear(){
    super();
    }
     void eat(){
         System.out.println(" UUMMMMM");
     }
}
