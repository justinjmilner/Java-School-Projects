
package July10.TestAbstract;

/**
 *
 * @author shohrehhadian-suleman
 */
public abstract class Fish extends Animal {
  
    String fin = "";
    abstract void eat();
}
