package July10.TestAbstract;

/**
 *
 * @author C0240467
 */
public class Dog extends Animal{

    public void sound() {
        System.out.println("Dog says : Woof Woof");

    }

    @Override
    void eat() {
        System.out.println("YUMMM!");
    }
}
